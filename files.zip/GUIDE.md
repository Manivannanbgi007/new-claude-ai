# Deploying user-service to Kind: the reference for all services

This guide deploys **user-service** and its **MySQL** database to a local Kind cluster using only
Kubernetes-native resources. Every other service follows the same pattern (section 15).

```
Windows ──(port-forward / NodePort 30092)──┐
                                           ▼
┌──────────────── Kind cluster "product-platform" ──── namespace product-platform ────────────────┐
│                                                                                                │
│   Service user-service (ClusterIP :8092) ──load-balances──► Pod user-service-xxxx  (worker 1)    │
│        ▲  DNS: user-service                              └► Pod user-service-yyyy  (worker 2)    │
│        │                                                          │ jdbc:mysql://mysql-user:3306 │
│   other services (later)                                         ▼                              │
│                                       Service mysql-user (headless) ──► Pod mysql-user-0        │
│   ConfigMap user-service-config ─┐                                         │                    │
│   Secret user-db-credentials ────┴──► environment variables of the Pods    └─► PVC data (2 Gi)  │
└────────────────────────────────────────────────────────────────────────────────────────────────┘
```

**No source code change is needed.** All Kubernetes-specific settings are environment variables that override
`application.yml`.

---

## Files

```
k8s-user-service/
├── kind/kind-cluster.yaml                   cluster: 1 control-plane + 2 workers
├── user-service-docker/                     → copy into the user-service project folder
│   ├── Dockerfile                           same pattern as eureka-server, port 8092
│   └── .dockerignore
└── k8s/
    ├── 00-namespace.yaml
    ├── mysql-user/
    │   ├── secret.yaml                      DB credentials (local learning only)
    │   ├── service.yaml                     headless Service
    │   └── statefulset.yaml                 MySQL 8.4 + PersistentVolumeClaim
    ├── user-service/
    │   ├── configmap.yaml                   settings as environment variables
    │   ├── deployment.yaml                  2 replicas, probes, resources, security
    │   ├── service.yaml                     ClusterIP: the stable internal address
    │   ├── pdb.yaml                         PodDisruptionBudget
    │   └── optional/                        NOT applied by default
    │       ├── service-nodeport.yaml        reach it from Windows at localhost:30092
    │       └── hpa.yaml                     autoscaling (needs metrics-server)
    └── event-schemas/                       REFERENCE for the Kafka phase (see section 16)
        ├── Dockerfile.registration
        └── schema-registration-job.yaml
```

All manifests were validated against the Kubernetes 1.33 API schemas, and the cross-file references (selectors,
ports, Secret keys) were checked.

---

## Prerequisites

| Tool | Check | Install |
|---|---|---|
| Docker Desktop (running) | `docker version` | docker.com |
| kind | `kind version` | `winget install Kubernetes.kind` |
| kubectl | `kubectl version --client` | `winget install Kubernetes.kubectl` |

Give Docker Desktop at least **6 GB** of memory (Settings → Resources) if the Docker Compose stack is also running.

**Create the cluster** (once):

```powershell
cd k8s-user-service
kind create cluster --config kind\kind-cluster.yaml
kubectl get nodes
```

Expect 3 nodes, all `Ready`: `product-platform-control-plane`, `product-platform-worker`, and
`product-platform-worker2`. Kind also points `kubectl` at this cluster (context `kind-product-platform`).

---

## 1. Build the Docker image

Copy `user-service-docker\Dockerfile` and `.dockerignore` into your **user-service** project folder (next to
`pom.xml`). Then:

```powershell
cd product-platform\user-service
docker build -t user-service:1.0.0 .
docker images user-service
```

The Dockerfile is the Eureka reference with only the port changed (8092). user-service needs neither Kafka nor
`event-schemas`, which is why it's the ideal first service.

**Always use a fixed version tag, never `latest`.** With a fixed tag you always know which code runs, and
`kubectl rollout undo` can go back to a previous version.

---

## 2. Make the image available to Kind

Kind's nodes are Docker containers with their **own** image store. They can't see the images on your Windows
Docker. Copy the image into the cluster:

```powershell
kind load docker-image user-service:1.0.0 --name product-platform
```

Verify that it's on a node:

```powershell
docker exec product-platform-worker crictl images | Select-String user-service
```

The Deployment uses `imagePullPolicy: IfNotPresent`, so Kubernetes uses this loaded image and never tries to
download it from Docker Hub.

**New version** = build with a new tag, `kind load` it, update the Deployment (section 13.4).

**In a real cluster**, images are pushed to a registry (Docker Hub, GHCR, ECR...) instead, and the Deployment
pulls them from there.

---

## 3. Create the Kubernetes resources

Apply in dependency order: namespace → database → application.

```powershell
cd k8s-user-service

# 3.1 Namespace: a "folder" for all platform resources
kubectl apply -f k8s\00-namespace.yaml

# 3.2 MySQL: Secret, headless Service, StatefulSet
kubectl apply -f k8s\mysql-user\
kubectl -n product-platform rollout status statefulset/mysql-user --timeout=180s

# 3.3 user-service: ConfigMap, Deployment, Service, PodDisruptionBudget
kubectl apply -f k8s\user-service\
kubectl -n product-platform rollout status deployment/user-service --timeout=300s
```

`kubectl apply -f <folder>` applies every file in that folder but **not** its subfolders, so `optional\` is
skipped on purpose.

`apply` is **declarative**: you describe the desired state, and Kubernetes makes it so. Run the same command
again after editing a file, and only the difference is changed.

To avoid typing `-n product-platform` every time:

```powershell
kubectl config set-context --current --namespace=product-platform
```

---

## 4. Configuration: ConfigMaps and Secrets

| | ConfigMap `user-service-config` | Secret `user-db-credentials` |
|---|---|---|
| Holds | Non-secret settings (DB URL, flags, logging) | Passwords |
| Stored as | Plain text | base64, **which is encoding, not encryption** |
| Used by | user-service (`envFrom`: all keys) | MySQL (all keys), user-service (only `username` and `password`) |

**How the values reach Spring Boot.** Every ConfigMap key becomes an environment variable, and Spring Boot maps
it to a property:

| Environment variable | Spring property | Purpose |
|---|---|---|
| `USER_DB_URL` | `${USER_DB_URL}` in `application.yml` | `mysql-user:3306` instead of `localhost:3309` |
| `EUREKA_CLIENT_ENABLED=false` | `eureka.client.enabled` | Kubernetes discovery replaces Eureka |
| `MANAGEMENT_ENDPOINT_HEALTH_PROBES_ENABLED` | `management.endpoint.health.probes.enabled` | `/actuator/health/liveness` and `/readiness` |
| `MANAGEMENT_ENDPOINT_HEALTH_GROUP_READINESS_INCLUDE` | `management.endpoint.health.group.readiness.include` | Readiness also checks the database |
| `SERVER_SHUTDOWN=graceful` | `server.shutdown` | Finish running requests on shutdown |
| `LOGGING_STRUCTURED_FORMAT_CONSOLE=ecs` | `logging.structured.format.console` | JSON logs on stdout |
| `LOGGING_FILE_NAME=""` | `logging.file.name` | No log file: Kubernetes collects stdout |

**Secrets in real environments: don't commit them.** `k8s\mysql-user\secret.yaml` is for local learning only.
The production way is to create the Secret directly:

```powershell
kubectl -n product-platform create secret generic user-db-credentials `
  --from-literal=database=user_db `
  --from-literal=username=user_user `
  --from-literal=password='<strong-password>' `
  --from-literal=root-password='<strong-root-password>'
```

Better still, let a tool manage it (Sealed Secrets, External Secrets Operator, or a cloud secret manager).

**Changing configuration.** Environment variables are read only when a container starts. After changing the
ConfigMap or Secret, restart the Pods with a rolling restart (no downtime):

```powershell
kubectl apply -f k8s\user-service\configmap.yaml
kubectl rollout restart deployment/user-service
```

**Note:** MySQL reads its passwords only when its data volume is **empty** (first start). Changing the Secret
later doesn't change the database user's password.

---

## 5. The Deployment

`k8s\user-service\deployment.yaml` tells Kubernetes *what* to run; the Deployment controller keeps it that way.

```
Deployment user-service ──manages──► ReplicaSet (one per version) ──manages──► Pods
```

| Part | What it does |
|---|---|
| `selector` + `template.metadata.labels` | How the Deployment finds "its" Pods; these must match |
| `strategy: RollingUpdate`, `maxSurge: 1`, `maxUnavailable: 0` | Updates start a new Pod, wait until it's **ready**, and only then stop an old one: zero downtime |
| `initContainers: wait-for-mysql` | Kubernetes has no `depends_on`. This waits until MySQL accepts connections, so the app never starts without its DB. |
| `securityContext` | Runs as user 1001 (non-root), no privilege escalation, read-only filesystem (except `/tmp`), no Linux capabilities |
| `topologySpreadConstraints` | Places the 2 replicas on different nodes when possible |
| `lifecycle.preStop.sleep: 10` | Waits 10 s before shutdown so routing to this Pod stops first (section 9) |
| `terminationGracePeriodSeconds: 45` | Upper limit for the shutdown: 10 s sleep + 20 s graceful shutdown fit inside |

---

## 6. Replicas

`replicas: 2` is set in the Deployment. Two replicas mean:

- one Pod can restart, move, or be updated while the other serves traffic;
- a node can fail;
- the PodDisruptionBudget (`pdb.yaml`, `minAvailable: 1`) keeps at least one Pod running during planned
  maintenance, such as a node drain.

**Scale by hand:**

```powershell
kubectl scale deployment/user-service --replicas=3
kubectl get pods -l app.kubernetes.io/name=user-service -o wide    # watch the NODE column
```

For permanent changes, edit `replicas:` in the YAML and `kubectl apply` it, so the file stays the truth.

**Optional: automatic scaling (HPA).** Kind has no metrics-server, so install it first:

```powershell
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml
kubectl -n kube-system patch deployment metrics-server --type=json `
  -p '[{"op":"add","path":"/spec/template/spec/containers/0/args/-","value":"--kubelet-insecure-tls"}]'
kubectl top pods                                   # works after ~1 minute
kubectl apply -f k8s\user-service\optional\hpa.yaml
kubectl get hpa user-service
```

The `--kubelet-insecure-tls` patch is needed only because Kind's kubelets use self-signed certificates. The HPA
keeps 2–5 Pods at ~70 % of the **CPU request**. While an HPA exists, it owns the replica count.

---

## 7. The Service

Pods are temporary: each new Pod gets a new IP address. The **Service** is the stable address in front of them:

```yaml
spec:
  type: ClusterIP                                   # internal only
  selector: { app.kubernetes.io/name: user-service }   # all Pods with this label...
  ports:
    - port: 8092                                    # ...reachable on this port
      targetPort: http                              # ...forwarded to the container port named "http"
```

**Only READY Pods receive traffic.** A Pod whose readiness probe fails is removed from the Service until it
recovers.

```powershell
kubectl get svc user-service
kubectl get endpointslices -l kubernetes.io/service-name=user-service    # the Pod IPs behind it
```

MySQL uses a **headless** Service (`clusterIP: None`): its name resolves directly to the Pod. That's what a
StatefulSet needs for its stable Pod names.

---

## 8. Service discovery: how services find each other

**Eureka is no longer needed.** Kubernetes has discovery built in:

```
order-service Pod                     CoreDNS                    kube-proxy (every node)
GET http://user-service:8092 ──► "user-service" = 10.96.x.y ──► picks a READY Pod ──► user-service Pod
```

1. Every Service gets a DNS name: `user-service` within the same namespace, or
   `user-service.product-platform.svc.cluster.local` in full.
2. The name resolves to the Service's stable virtual IP.
3. Connections are spread across the ready Pods.

| | Eureka (Docker Compose) | Kubernetes |
|---|---|---|
| Registration | The app registers itself | Automatic: Pod labels match the Service selector |
| Address | `lb://user-service` (client-side load balancing) | `http://user-service:8092` (DNS + kube-proxy) |
| Health | Heartbeats every 30 s | Readiness probe, every 5 s |
| Extra server | eureka-server | None |

**Try it from inside the cluster:**

```powershell
kubectl run dns-test --rm -it --restart=Never --image=busybox:1.36 -- sh -c `
  "nslookup user-service; wget -qO- http://user-service:8092/actuator/health"
```

**Consequence for the other services.** When the **api-gateway** moves to Kubernetes, its routes change from
`uri: lb://user-service` to `uri: http://user-service:8092`, again through an environment variable or a
Kubernetes-specific YAML, not code. That route still gets all the gateway filters (rate limiting, circuit breaker
...). An alternative is *Spring Cloud Kubernetes*, which makes `lb://` work against the Kubernetes API. Plain
DNS is simpler and teaches you how Kubernetes works.

---

## 9. Health checks: startup, liveness, and readiness probes

Spring Boot provides two probe endpoints (enabled through the ConfigMap):

| Probe | Endpoint | Question | When it fails |
|---|---|---|---|
| **startupProbe** | `/actuator/health/liveness` | "Has it finished starting?" (up to 30 × 5 s = 150 s) | Container restarted. Liveness and readiness wait until this succeeds. |
| **livenessProbe** | `/actuator/health/liveness` | "Is the app alive, or stuck?" | **Container restarted** after 3 failures |
| **readinessProbe** | `/actuator/health/readiness` (app **+ database**) | "May it receive traffic?" | **Removed from the Service**, *not* restarted |

**The most important rule: liveness must NOT check the database.** If MySQL is down, restarting user-service
fixes nothing: every Pod would restart over and over, causing a restart storm. So the database is only part of
**readiness**: the Pods stay alive and simply receive no traffic until the DB is back.

**See it happen:**

```powershell
kubectl scale statefulset/mysql-user --replicas=0
kubectl get pods -l app.kubernetes.io/name=user-service -w
```

The Pods become `0/1` READY but stay `Running` with `RESTARTS 0`. Stop watching with Ctrl+C, then bring MySQL
back:

```powershell
kubectl scale statefulset/mysql-user --replicas=1
```

After a short while the Pods are `1/1` again.

**Graceful shutdown.** When a Pod is deleted, Kubernetes removes it from the Service *and* sends the stop signal
**at the same time**. The `preStop` sleep (10 s) lets all nodes stop routing to it first. Then Spring's graceful
shutdown finishes the running requests (up to 20 s), all within `terminationGracePeriodSeconds: 45`.

---

## 10. Resources: requests and limits

```yaml
resources:
  requests: { cpu: 250m, memory: 512Mi }   # RESERVED: the scheduler only places the Pod where this is free
  limits:   { cpu: "1",  memory: 768Mi }   # MAXIMUM
```

| | Exceeded → |
|---|---|
| Memory limit | Container **killed** (`OOMKilled`) and restarted |
| CPU limit | **Throttled**: the app gets slower, but isn't killed |

**The JVM and memory.** The Dockerfile sets `-XX:MaxRAMPercentage=75`, so the heap gets 75 % of the
**container limit** (~576 MiB of 768 MiB). The remaining ~190 MiB is for metaspace, threads, and buffers. Never
set the heap to 100 % of the limit, or the container will be OOMKilled.

**How to pick the values:** start with these, watch real usage (`kubectl top pods` with metrics-server), then
set the requests near normal usage and the memory limit with headroom. `cpu: 250m` = a quarter of one CPU core.

**The CPU limit is a trade-off.** The JVM needs much more CPU while starting than while running. A low CPU limit
makes startup slow, which is one reason for the generous startup probe. Many teams set **no CPU limit** in
production and rely on requests.

---

## 11. Environment variables

The container gets its environment from two sources (`deployment.yaml`):

```yaml
envFrom:                                   # ALL keys of the ConfigMap
  - configMapRef: { name: user-service-config }
env:                                       # SINGLE keys from the Secret
  - name: USER_DB_PASSWORD
    valueFrom: { secretKeyRef: { name: user-db-credentials, key: password } }
```

- **Only what the app needs:** user-service references `username` and `password`, not `root-password`. The
  MySQL root password never appears in its environment.
- **Precedence:** values in `env` override `envFrom`. Environment variables override `application.yml` in the
  image.
- **Image defaults:** `JAVA_TOOL_OPTIONS` (JVM settings) comes from the Dockerfile. To override it for one
  service, add it to `env`.

See what a running Pod got (the password is visible here, so mind who can run this command):

```powershell
kubectl exec deploy/user-service -- env | Sort-Object
```

---

## 12. Exposing the application

| Method | Use | Command / file |
|---|---|---|
| **Port-forward** | Developers, debugging, quick tests | `kubectl port-forward svc/user-service 8092:8092` → http://localhost:8092 |
| **NodePort** (optional) | Learning: a fixed port on the node | `kubectl apply -f k8s\user-service\optional\service-nodeport.yaml` → http://localhost:30092 (mapped in `kind-cluster.yaml`) |
| **Gateway API / Ingress** | Production entry point | Later, **for the api-gateway only** |

**Target architecture: only the api-gateway is public.** user-service, MySQL, and every other backend stay
`ClusterIP` (internal). That's the same principle as today, where clients go through port 8080. Delete the
NodePort Service once the gateway runs in the cluster.

For the production entry point, use the **Gateway API**, the Kubernetes-native successor to Ingress, with an
implementation such as Envoy Gateway or NGINX Gateway Fabric. The widely used community **ingress-nginx**
controller was retired by the Kubernetes project (announced November 2025), so it isn't a good choice for new
setups.

---

## 13. Verify that everything works

### 13.1 Resources and Pods

```powershell
kubectl get all -n product-platform
kubectl get pods -o wide
```

**Expected:**

- `mysql-user-0` is `1/1 Running`.
- Two `user-service-...` Pods are `1/1 Running` with `RESTARTS 0`, ideally on different worker nodes.
- The PVC is `Bound`: `kubectl get pvc`.

### 13.2 Logs (JSON, one line per event)

```powershell
kubectl logs deploy/user-service --tail=20
kubectl logs deploy/user-service -c wait-for-mysql     # the init container
```

Look for `Started UserServiceApplication` and Flyway's `Successfully applied 1 migration`. Only the first Pod
applies it; the second finds it already done.

### 13.3 Call the API

```powershell
kubectl port-forward svc/user-service 8092:8092     # leave running; use a second terminal:

Invoke-RestMethod http://localhost:8092/actuator/health/readiness
$user = Invoke-RestMethod -Method Post -Uri http://localhost:8092/api/v1/users -ContentType "application/json" `
  -Body '{"email":"asha.k@example.com","firstName":"Asha","lastName":"Kumar","phoneNumber":"+919876543210"}'
$user
Invoke-RestMethod "http://localhost:8092/api/v1/users?q=asha"
```

**Expected:** readiness `UP`; the created user with an `id`; the search finds it.

### 13.4 Rolling update and rollback

```powershell
docker build -t user-service:1.0.1 .                       # in the user-service folder
kind load docker-image user-service:1.0.1 --name product-platform
kubectl set image deployment/user-service user-service=user-service:1.0.1
kubectl rollout status deployment/user-service              # new Pods start, old ones stop: no downtime
kubectl rollout history deployment/user-service
kubectl rollout undo deployment/user-service                # back to 1.0.0
```

Afterwards, update `image:` in `deployment.yaml` to the version you keep, so the file stays the truth.

### 13.5 Self-healing and persistence

```powershell
kubectl delete pod -l app.kubernetes.io/name=user-service --wait=false
kubectl get pods -w        # the Deployment creates replacements immediately
kubectl delete pod mysql-user-0
kubectl get pods -w        # recreated with the SAME name and the SAME volume
```

Call `GET /api/v1/users?q=asha` again: the user from 13.3 still exists, because the data survived on the PVC.

---

## 14. Troubleshooting

**The 4 commands that solve most problems:**

```powershell
kubectl get pods                                  # STATUS column
kubectl describe pod <pod-name>                   # read "Events" at the bottom
kubectl logs <pod-name> [-c <container>] [--previous]   # --previous = the crashed run
kubectl get events --sort-by=.lastTimestamp
```

| STATUS / symptom | Cause | Fix |
|---|---|---|
| `ErrImagePull` / `ImagePullBackOff` | Image not loaded into Kind, or the tag differs | `kind load docker-image user-service:1.0.0 --name product-platform`; compare the tag with `deployment.yaml` |
| `Init:0/1` for a long time | MySQL not reachable | `kubectl logs <pod> -c wait-for-mysql`; check `kubectl get pods` for mysql-user |
| `CreateContainerConfigError` | ConfigMap/Secret or a key missing | `describe pod` names it; `kubectl get configmap,secret` |
| `CrashLoopBackOff` | The app exits at startup | `kubectl logs <pod> --previous`: usually DB credentials or a config typo |
| `Running` but `0/1` READY | Readiness failing (DB down?) | `kubectl exec deploy/user-service -- wget -qO- localhost:8092/actuator/health/readiness` |
| `OOMKilled` (in `describe`) | Memory limit too low | Raise `limits.memory`; keep `MaxRAMPercentage` at 75 |
| Restarted again and again during startup | Startup too slow for the probe | Raise the `startupProbe` `failureThreshold` |
| `Pending` | Not enough CPU/memory on the nodes, or the PVC isn't bound | `describe pod` → "Insufficient memory": lower the requests or give Docker more memory |
| MySQL `Access denied` | Secret changed after the first start | The DB user keeps its old password. Delete the volume and start fresh: `kubectl delete statefulset mysql-user; kubectl delete pvc data-mysql-user-0` (**deletes the data**), then apply again |
| Service has no endpoints | Selector doesn't match the Pod labels, or no Pod is ready | `kubectl get endpointslices -l kubernetes.io/service-name=user-service` |
| Port-forward: `address already in use` | user-service from Docker Compose / the IDE already uses 8092 | `kubectl port-forward svc/user-service 18092:8092` |

**Start over completely:** `kind delete cluster --name product-platform`, then repeat from Prerequisites.

---

## 15. The same pattern for every other service

For each service, copy the `k8s\user-service\` folder and change these values:

| Change | Where |
|---|---|
| Name and labels (`user-service` → `order-service`) | All files |
| Port (`8092` → e.g. `8084`) | `deployment.yaml` (containerPort), `service.yaml` |
| Image (`user-service:1.0.0`) | `deployment.yaml` |
| Environment variables (DB URL, Kafka, ...) | `configmap.yaml` |
| Secret references | `deployment.yaml` `env` |
| Init container (what to wait for) | `deployment.yaml` |
| Resources | `deployment.yaml`: e.g. rag-service and mcp-client need more memory |

**Stays identical:** the probes, rolling update strategy, security context, preStop/grace period, PDB, and
labels scheme.

**Each database** gets its own folder like `mysql-user\` (Secret, headless Service, StatefulSet). That's still
"database per service", now with one StatefulSet each.

**Settings that apply to every Spring service** (in each ConfigMap):

```yaml
EUREKA_CLIENT_ENABLED: "false"
MANAGEMENT_ENDPOINT_HEALTH_PROBES_ENABLED: "true"
MANAGEMENT_ENDPOINT_HEALTH_GROUP_READINESS_INCLUDE: "readinessState,db"   # adjust: e.g. add elasticsearch
SERVER_SHUTDOWN: "graceful"
LOGGING_STRUCTURED_FORMAT_CONSOLE: "ecs"
LOGGING_FILE_NAME: ""
```

**Special cases to plan for:**

- **Kafka consumers** (order, stock, product): the readiness group shouldn't depend on Kafka being up (it only
  needs to reach its own DB). Kafka outages are handled by the consumers' retry logic.
- **api-gateway:** routes become `http://<service>:<port>` instead of `lb://`. It's the only service with an
  external entry point (Gateway API). Redis moves in as its own StatefulSet.
- **rag-service, mcp-client:** long timeouts and more memory; Ollama needs a PVC for its models.

Once 3–4 services exist, use **Kustomize** (built into `kubectl apply -k`) to share the common parts instead of
copying them. Learn the plain YAML first.

---

## 16. `event-schemas` on Kubernetes

**`event-schemas` is not deployed as an application, because it isn't one.** It's a JAR library with no `main`
method, no port, and nothing that runs. Creating a Deployment or Service for it would be a mistake. It has two
concerns, and Kubernetes plays a role in only one of them:

### 16.1 Build time: services compile against it

order, stock, product-write, and product need the JAR **while their Docker image is built**. On your machine it
comes from `~/.m2`, but a clean Docker build can't see that folder. Options, from simplest to most "real":

| Option | How | When |
|---|---|---|
| **Build it inside the image build** | Docker build context = `product-platform\`; the build stage runs `mvn install` in `event-schemas`, then `mvn package` in the service | Local and Kind: simple, no extra server |
| **Artifact repository** (recommended for teams/CI) | `mvn deploy` event-schemas (versioned: 1.0.0, 1.1.0 ...) to GitHub Packages, Nexus, or AWS CodeArtifact; services download it like any dependency | Real projects with CI/CD |

The artifact repository is the industry standard: every service declares *which* schema version it was built
with, and releases are reproducible. A repository like Nexus *can* itself run in Kubernetes (Deployment + PVC),
but usually it's a shared team service outside the application cluster.

### 16.2 Runtime: the schemas must be registered in Schema Registry

This is a **task that runs once and finishes** per release, so the Kubernetes-native resource is a **Job**:

```
new event-schemas release ──► docker build -f Dockerfile.registration ──► kind load
                         ──► kubectl apply -f schema-registration-job.yaml
                             Job: wait for schema-registry ─► test-compatibility ─► register ─► Completed
                         ──► THEN deploy the producers (order, stock, product-write) with the new version
```

The files are in `k8s\event-schemas\` as a **reference for the Kafka phase**; they need Schema Registry running
in the cluster first:

| Resource | Purpose |
|---|---|
| `Dockerfile.registration` | A small image containing `pom.xml` + the `.avsc` files; runs the existing `kafka-schema-registry-maven-plugin` |
| ConfigMap `event-schemas-config` | `SCHEMA_REGISTRY_URL=http://schema-registry:8081`, passed as `-Dschema.registry.url` (that property already exists in `pom.xml`) |
| Job `event-schemas-registration-1-0-0` | Init container waits for Schema Registry; `test-compatibility` first, so an incompatible schema **fails the Job before anything is registered**; `backoffLimit: 3`; auto-deleted after 1 day |

The version is part of the Job name because a Job's template can't be changed: each release gets a new Job,
which also leaves a visible history.

---

## 17. Migrating from Docker Compose to Kubernetes

**Move whole slices, not single containers.** Avoid a long hybrid where Pods in Kind call containers in Compose:
it's possible (`host.docker.internal`), but networking, ports, and DNS get confusing and teach the wrong things.
Instead, each phase brings a service **together with its dependencies** into the cluster:

| Phase | What moves | Kubernetes resources learned |
|---|---|---|
| **1** (this guide) | user-service + mysql-user | Namespace, Deployment, StatefulSet, PVC, Service, ConfigMap, Secret, probes, resources, PDB |
| **2** | api-gateway + Redis; gateway routes → `http://user-service:8092` | External exposure (NodePort → Gateway API), service-to-service DNS |
| **3** | Kafka (KRaft) + Schema Registry + **event-schemas Job** | StatefulSet with multiple PVCs, Jobs, startup ordering |
| **4** | stock, order, product-write (+ their MySQL), Kafka Connect/Debezium, product-service + Elasticsearch | The saga across Pods; CDC; init Jobs (topics, connector registration) |
| **5** | rag-service (PostgreSQL + pgvector, reranker), Ollama, mcp-server, mcp-client | Large memory, model PVCs, long timeouts |
| **6** | Observability: Loki + Grafana (stdout JSON logs are already ready) | DaemonSets (log collectors) |

**Compose → Kubernetes, item by item:**

| docker-compose.yml | Kubernetes |
|---|---|
| Application container | Deployment + Service |
| Database container + named volume | StatefulSet + headless Service + `volumeClaimTemplates` |
| `environment:` | ConfigMap + Secret |
| `.env` file | ConfigMap values / Secret values |
| `healthcheck:` | readiness/liveness/startup probes |
| `depends_on: condition: service_healthy` | initContainer + readiness probes + application retries |
| `ports: "127.0.0.1:8092:8092"` | Internal: ClusterIP Service. External: port-forward / NodePort / Gateway API |
| `restart: unless-stopped` | Controllers (Deployment, StatefulSet) |
| One-off init containers (`kafka-init`, `debezium-init`, `ollama-model-init`) | Jobs |
| Eureka server | Not needed: Service + DNS |
| `container_name` as hostname | Service name as DNS name |

**Infrastructure in production.** Kafka, Elasticsearch, and PostgreSQL are usually run either by **operators**
(Strimzi for Kafka, ECK for Elasticsearch, CloudNativePG for PostgreSQL) or as **managed cloud services**. For
learning, plain StatefulSets show you how it works underneath; switch to operators when you need replication,
backups, and upgrades.

**Your daily development loop doesn't have to change.** Docker Compose + IDE stays the fast local loop.
Kubernetes is where you learn deployment and how the system behaves in production. Over time, the Compose file
shrinks as each phase moves to the cluster.
